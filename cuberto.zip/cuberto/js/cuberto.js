const wholescreen = window;
const circle =document.getElementById('mouse-dot')
wholescreen.addEventListener('mouseover', function(e) {
    var mousex=e.clientX
    var mousey=e.clienty
    setTimeout(function() {
        circle.style.left = mousex + 'px';
        circle.style.top = mousey + 'px';
    }, 200);
});


// circle.addEventListener('mouseover', function(e)){
//     var circlex=e.clientX
//     var circley=e.clienty
//     e.clientX=mousex
//     e.clienty=mousey
// }


